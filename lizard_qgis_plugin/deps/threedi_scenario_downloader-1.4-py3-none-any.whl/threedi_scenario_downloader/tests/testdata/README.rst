Just a dir for some test data.
